<?php

// add_shortcode( 'bold', 'shortcode_bold' );
// function shortcode_bold( $atts, $content ) {
// 	$atts = shortcode_atts(
// 		array(
// 			'attribute' => 'default_value'
// 		),
// 		$atts
// 	);

// 	return '<strong>' . $content . '</strong>';
// }
