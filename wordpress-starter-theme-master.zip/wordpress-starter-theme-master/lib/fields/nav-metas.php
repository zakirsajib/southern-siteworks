<?php

/*
use Carbon_Fields\Container;
use Carbon_Fields\Field;

Container::make( 'nav_menu_item', __('Menu Item Settings', THEME_TEXTDOMAIN) )
    ->add_fields(
    	array(
	        Field::make( 'image', 'bg_image', __('Background Image', THEME_TEXTDOMAIN) )
	    )
	);
*/