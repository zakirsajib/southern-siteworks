<?php

/*
use Carbon_Fields\Container;
use Carbon_Fields\Field;

Container::make( 'term_meta', __('Service Category Settings', THEME_TEXTDOMAIN) )
    ->show_on_taxonomy('service-category')
	->add_fields(
		array(
			Field::make( 'image', 'service_category_icon', __('Icon', THEME_TEXTDOMAIN) )
		)
	);
*/