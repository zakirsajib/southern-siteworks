<?php

use Carbon_Fields\Container;
use Carbon_Fields\Field;

Container::make( 'theme_options', __('Theme Options', THEME_TEXTDOMAIN) )
	->add_tab(
        __('General', THEME_TEXTDOMAIN),
        array(
			Field::make( 'image', 'logo', __('Logo', THEME_TEXTDOMAIN) )
				->set_width(25),
			Field::make( 'image', 'logo_icon', __('Logo Icon', THEME_TEXTDOMAIN) )
				->set_width(25),
			Field::make( 'image', 'logo_raster_colorful', __('Logo Raster (Colorful)', THEME_TEXTDOMAIN) )
				->set_width(25),
			Field::make( 'image', 'logo_raster_white', __('Logo Raster (White)', THEME_TEXTDOMAIN) )
				->set_width(25)
        )
	)
	
	->add_tab(
        __('Instagram', THEME_TEXTDOMAIN),
        array(
			Field::make( 'text', 'instagram_app_id', __('Instagram App ID', THEME_TEXTDOMAIN) )
				->set_width(33),
			Field::make( 'text', 'instagram_app_secret', __('Instagram App Secret', THEME_TEXTDOMAIN) )
				->set_width(33),
			Field::make( 'text', 'instagram_access_token', __('Instagram Access Token', THEME_TEXTDOMAIN) )
				->set_width(33)
        )
	)
	
	->add_tab(
        __('BirdEye', THEME_TEXTDOMAIN),
        array(
			Field::make( 'text', 'birdeye_business_id', __('BirdEye Business ID', THEME_TEXTDOMAIN) )
				->set_width(50),
			Field::make( 'text', 'birdeye_api_key', __('BirdEye API Key', THEME_TEXTDOMAIN) )
				->set_width(50)
        )
	);