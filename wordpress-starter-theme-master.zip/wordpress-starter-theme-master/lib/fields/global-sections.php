<?php

/*
use Carbon_Fields\Container;
use Carbon_Fields\Field;

Container::make( 'theme_options', __('Global Sections', THEME_TEXTDOMAIN) )
	->add_tab(
        __('Contact Us Section', THEME_TEXTDOMAIN),
        array(
			Field::make( 'text', 'contact_us_section_heading', __('Heading', THEME_TEXTDOMAIN) ),
			Field::make( 'text', 'contact_us_section_form_id', __('Form ID', THEME_TEXTDOMAIN) )
        )
	);
*/