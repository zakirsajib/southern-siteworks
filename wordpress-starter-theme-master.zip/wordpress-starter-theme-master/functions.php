<?php

use Carbon_Fields\Carbon_Fields;
use Harbinger_Marketing\Assets_Cache;
use Harbinger_Marketing\PDF_Generator;
use Harbinger_Marketing\Instagram_Media;
use Harbinger_Marketing\BirdEye_Reviews;

add_action('after_setup_theme', 'load_theme_dependencies');
function load_theme_dependencies() {
	require_once('vendor/autoload.php');

	require_once('config/constants.php');

	require_once('lib/checks.php');

	require_once('lib/helpers/generic.php');
	require_once('lib/helpers/geolocation.php');
	require_once('lib/helpers/media.php');
	require_once('lib/helpers/svg.php');
	require_once('lib/helpers/image.php');
	require_once('lib/helpers/video.php');
	require_once('lib/helpers/ninja-forms.php');
	require_once('lib/helpers/wp.php');
}

add_action('after_setup_theme', 'init_carbon_fields');
function init_carbon_fields() {
	Carbon_Fields::boot();

	add_action('carbon_fields_register_fields', function() {
		require_once('lib/fields/post-metas.php');
		require_once('lib/fields/term-metas.php');
		require_once('lib/fields/nav-metas.php');
		require_once('lib/fields/widgets.php');
		require_once('lib/fields/global-sections.php');
		require_once('lib/fields/theme-options.php');
	});
}

add_action('init', 'init_classes');
function init_classes() {
	PDF_Generator::init();
	
	Instagram_Media::init( carbon_get_theme_option('instagram_app_id'), carbon_get_theme_option('instagram_app_secret'), carbon_get_theme_option('instagram_access_token') );
}

add_action('init', 'init_theme');
function init_theme() {
	require_once('config/constants-dependent.php');

	require_once('lib/branding.php');
	require_once('lib/post-types.php');
	require_once('lib/menus/menus.php');
	require_once('lib/sidebars.php');
	require_once('lib/shortcodes.php');
	require_once('lib/emails/emails.php');

	load_theme_textdomain( THEME_TEXTDOMAIN, get_stylesheet_directory() . '/languages' );

	add_theme_support('post-thumbnails');
	add_theme_support('title-tag');

	add_image_size('full-hd', 1920, 0, 1);
}

add_action('wp_enqueue_scripts', 'enqueue_scripts');
function enqueue_scripts() {
	wp_enqueue_script( THEME_TEXTDOMAIN . '-vendor', get_bloginfo('stylesheet_directory') . '/assets/theme/js/vendor.js', array('jquery'), false, true );
	wp_enqueue_script( THEME_TEXTDOMAIN . '-main', get_bloginfo('stylesheet_directory') . '/assets/theme/js/main.js', array('jquery'), false, true );
}

add_action('wp_enqueue_scripts', 'enqueue_styles');
function enqueue_styles() {
	wp_enqueue_style( THEME_TEXTDOMAIN . '-style', get_bloginfo('stylesheet_directory') . '/assets/theme/css/styles.css' );
}